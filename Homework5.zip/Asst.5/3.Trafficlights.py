from tkinter import *     # Import all definitions from tkinter

class TrafficLights: 
    def __init__(self):
        window = Tk()     # Create a window 
        window.title("Traffic Lights")        # Set title 
        self.canvas = Canvas(window, width =230, height = 330, bg = "white")
        self.canvas.pack() 
        
        # Place canvas in the window 
        frame = Frame(window)    
        frame.pack() 
      
        self.color = StringVar()

        radio_red = Radiobutton(frame, text="Red", variable=self.color, value="R", command=self.on_RadioChange)
        radio_red.grid(row=1, column=1)

        radio_yellow = Radiobutton(frame, text="Yellow", variable=self.color, value="Y", command=self.on_RadioChange)               
        radio_yellow.grid(row = 1, column = 2)
        
        radio_green = Radiobutton(frame, text="Green", variable=self.color, value="G", command=self.on_RadioChange)
        radio_green.grid(row = 1, column = 3)

        
        self.rectangle = self.canvas.create_rectangle(75, 15, 150, 330) 
           
        self.oval_red =  self.canvas.create_oval(75, 15, 150, 110, fill="white")
        self.oval_yellow =  self.canvas.create_oval(75, 125, 150, 220, fill="white")
        self.oval_green = self.canvas.create_oval(75, 230, 150, 330, fill="white")
        window.mainloop()
    def on_RadioChange(self):
   
        color = self.color.get()
      
        if color == 'R':
            self.canvas.itemconfig(self.oval_red, fill="red")
            self.canvas.itemconfig(self.oval_yellow, fill="white")
            self.canvas.itemconfig(self.oval_green, fill="white")
        elif color == 'Y':
            self.canvas.itemconfig(self.oval_red, fill="white")
            self.canvas.itemconfig(self.oval_yellow, fill="yellow")
            self.canvas.itemconfig(self.oval_green, fill="white")
        elif color == 'G':
            self.canvas.itemconfig(self.oval_red, fill="white")
            self.canvas.itemconfig(self.oval_yellow, fill="white")
            self.canvas.itemconfig(self.oval_green, fill="green")   
           
TrafficLights() # Create GUI 