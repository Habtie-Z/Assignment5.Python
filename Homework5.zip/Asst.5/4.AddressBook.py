from tkinter import *

class AddressBook:
    '''
        This function constructos the AddressBook class
    '''
    def __init__(self):
        window = Tk()
        window.title("AddressBook")
        window.geometry('500x100')

        Label(window, text="Name").grid(row=1, column=1, sticky=W)
        Label(window, text="Street").grid(row=2, column=1, sticky=W)
        Label(window, text="City").grid(row=3, column=1, sticky=W)
        Label(window, text="State").grid(row=3, column=3, sticky=W)
        Label(window, text="ZIP").grid(row=3, column=5, sticky=W)

        self.nameVar = StringVar()
        Entry(window, textvariable = self.nameVar, justify=RIGHT).grid(row =1, column=2)

        self.streetVar = StringVar()
        Entry(window, textvariable = self.streetVar, justify=RIGHT).grid(row =2, column=2)

        self.cityVar = StringVar()
        Entry(window, textvariable = self.cityVar, justify=RIGHT).grid(row =3, column=2)

        self.stateVar = StringVar()
        Entry(window, textvariable = self.stateVar, justify=CENTER).grid(row =3, column=4)

        self.zipVar = StringVar()
        Entry(window, textvariable = self.zipVar, justify=RIGHT).grid(row =3, column=6)

      
        btn = Button(window, text="Add")
        btn.grid(column=2, row=4)
        btn = Button(window, text="First")
        btn.grid(column=3, row=4)
        btn = Button(window, text="Next")
        btn.grid(column=4, row=4)
        btn = Button(window, text="Previous")
        btn.grid(column=5, row=4)
        btn = Button(window, text="Last")
        btn.grid(column=6, row=4)
        window.mainloop()

AddressBook()