from tkinter import *              # Import all definitions from tkinter

class AlternateMessages: 
    def __init__(self):
        window = Tk()      # Create a window          
        window.title("Alternate Messages")    # Set a title
        width = 300    # Width of the canvas 
        canvas = Canvas(window, bg ="white", width =300, height = 60)
        canvas.pack()
        x = 30        # Starting x position 
        canvas.create_text(x,30, text = "Programming is fun", tags = "text")
        dx = 3
        while True:
            canvas.move("text", dx, 0)    # Move text dx unit
            canvas.after(20)      # Sleep for 20 milliseconds
            canvas.update()     # Update canvas
            if x < width:
                x += dx    # Get the current position for string
            else: 
                x = 3      # Reset string position to the beginning
                canvas.create_text(x, 30, text = "It is fun to program", tags = "text") 
        window.mainloop()      # Create an event loop 
         
AlternateMessages()       # Create GUI